# 🌿 WildGuard

> Platform web edukasi untuk mengenal flora dan fauna yang dilindungi serta meningkatkan kesadaran masyarakat terhadap perdagangan ilegal satwa liar sebagai bentuk dukungan terhadap SDG 15.7.

---

## 👥 Anggota Kelompok

| No | Nama | NIM |
|----|------|-----|
| 1 | Kaila Audriya Setiawan | 140810250007 | 
| 2 | Farah Nadia Aqila | 140810250049 |
| 3 | Naura Alifia Lubna | 140810250088 | 


---

## Fungsi

WildGuard berfungsi sebagai platform edukasi yang membantu masyarakat untuk:

- Mengenal flora dan fauna yang dilindungi.
- Mengetahui status perlindungan suatu spesies.
- Memahami ancaman terhadap flora dan fauna.
- Meningkatkan kesadaran mengenai perdagangan ilegal satwa liar.
- Mencatat dugaan temuan perdagangan ilegal flora dan fauna.

---

## Tujuan

WildGuard dibuat untuk mendukung **Sustainable Development Goals (SDGs) Tujuan 15: Life on Land**, khususnya target **SDG 15.7**.

Tujuan WildGuard adalah meningkatkan kesadaran masyarakat mengenai pentingnya perlindungan flora dan fauna serta memberikan edukasi mengenai ancaman perdagangan ilegal terhadap keanekaragaman hayati.

### SDG 15.7

Mengambil tindakan untuk mengakhiri perburuan dan perdagangan ilegal spesies flora dan fauna yang dilindungi.

---

## Target Pengguna

WildGuard ditujukan untuk:

- Pelajar dan mahasiswa.
- Masyarakat umum.
- Pecinta lingkungan dan satwa.
- Orang yang ingin mempelajari flora dan fauna Indonesia.

---

## Mockup Kasar

###
