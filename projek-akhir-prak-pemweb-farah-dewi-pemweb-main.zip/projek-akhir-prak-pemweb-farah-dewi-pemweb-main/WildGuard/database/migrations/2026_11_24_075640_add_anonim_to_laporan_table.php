<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('laporan', function (Blueprint $t) {
            $t->boolean('anonim')->default(false)->after('id_user');
        });
    }

    public function down(): void
    {
        Schema::table('laporan', function (Blueprint $t) {
            $t->dropColumn('anonim');
        });
    }
};
