<?php

namespace App\Http\Controllers;

use App\Http\Concerns\PesanValidasi;
use App\Http\Concerns\SimpanLampiran;
use App\Models\JenisTemuan;
use App\Models\Laporan;
use App\Models\Spesies;
use App\Support\Kembali;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LaporanController extends Controller
{
    use PesanValidasi, SimpanLampiran;

    private function rules(): array
    {
        return [
            'id_jenis' => ['required', 'exists:jenis_temuan,id_jenis'],
            'id_spesies' => ['nullable', 'exists:spesies,id_spesies'],
            'lokasi_kejadian' => ['required', 'min:3', 'max:200'],
            'tanggal_kejadian' => ['required', 'date', 'before_or_equal:today'],
            'deskripsi' => ['required', 'min:20'],
            'status_laporan' => ['required', Rule::in(['baru', 'diproses', 'selesai'])],
        ];
    }

    private function attrs(): array
    {
        return [
            'id_jenis' => 'Jenis temuan', 'id_spesies' => 'Spesies',
            'lokasi_kejadian' => 'Lokasi kejadian', 'tanggal_kejadian' => 'Tanggal kejadian',
            'deskripsi' => 'Deskripsi', 'status_laporan' => 'Status laporan',
        ];
    }

    private function formData(Laporan $laporan): array
    {
        return [
            'row' => $laporan,
            'jenis' => JenisTemuan::orderBy('id_jenis')->get(),
            'spesies' => Spesies::orderBy('nama')->get(),
        ];
    }

    public function index(Request $request)
    {
        $status = $request->query('status', '');
        $rows = Laporan::with(['jenis', 'spesies'])
            ->when(in_array($status, ['baru', 'diproses', 'selesai'], true),
                fn($q) => $q->where('status_laporan', $status))
            ->orderByDesc('created_at')->get();
        return view('laporan.index', compact('rows', 'status'));
    }

    public function create()
    {
        return view('laporan.form', $this->formData(new Laporan([
            'tanggal_kejadian' => now(), 'status_laporan' => 'baru',
        ])));
    }

    public function store(Request $request)
    {
        $data = $request->validate($this->rules(), $this->pesan(), $this->attrs());
        $data['id_spesies'] = $data['id_spesies'] ?: null;
        Laporan::create($data);
        return redirect()->route('laporan.index')->with('ok', 'Laporan berhasil dikirim.');
    }

    public function edit(Request $request, Laporan $laporan)
    {
        return view('laporan.form', $this->formData($laporan))
            ->with('kembali', $request->query('kembali'));
    }

    public function update(Request $request, Laporan $laporan)
    {
        $data = $request->validate($this->rules(), $this->pesan(), $this->attrs());
        $data['id_spesies'] = $data['id_spesies'] ?: null;
        $laporan->update($data);
        return redirect(Kembali::url($request->input('kembali'), route('laporan.index')))
            ->with('ok', 'Laporan berhasil diperbarui.');
    }

    public function destroy(Request $request, Laporan $laporan)
    {
        $this->hapusLampiran($laporan->lampiran);
        $laporan->delete();
        return redirect(Kembali::url($request->input('kembali'), route('laporan.index')))
            ->with('ok', 'Laporan berhasil dihapus.');
    }
}
