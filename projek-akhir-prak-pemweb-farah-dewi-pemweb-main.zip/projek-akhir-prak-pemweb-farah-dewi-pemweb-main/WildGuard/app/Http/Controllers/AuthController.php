<?php

namespace App\Http\Controllers;

use App\Http\Concerns\PesanValidasi;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    use PesanValidasi;

    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $cred = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ], $this->pesan(), ['email' => 'Email', 'password' => 'Password']);

        if (!Auth::attempt($cred, $request->boolean('ingat'))) {
            return back()->withInput($request->only('email'))
                ->withErrors(['email' => 'Email atau password salah.']);
        }

        $request->session()->regenerate();
        $default = Auth::user()->role === 'admin' ? route('admin.dashboard') : route('laporan-saya.index');
        return redirect()->intended($default);
    }

    public function showRegister()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'email', 'max:150', 'unique:users,email'],
            'password' => ['required', 'min:8', 'confirmed'],
        ], $this->pesan(), [
            'name' => 'Nama', 'email' => 'Email', 'password' => 'Password',
        ]);

        // forceFill: kolom role tidak ada di $fillable bawaan User, jadi diisi eksplisit
        $user = (new User())->forceFill([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'role' => 'user', // pendaftar publik selalu user biasa
        ]);
        $user->save();

        Auth::login($user);
        $request->session()->regenerate();
        return redirect()->route('laporan-saya.index')->with('ok', 'Akun berhasil dibuat. Selamat datang!');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('home');
    }
}
