<?php

namespace App\Http\Controllers;

use App\Http\Concerns\PesanValidasi;
use App\Models\Laporan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

// CRUD pengguna (khusus admin)
class UserController extends Controller
{
    use PesanValidasi;

    private function attrs(): array
    {
        return ['name' => 'Nama', 'email' => 'Email', 'password' => 'Password', 'role' => 'Peran'];
    }

    public function index()
    {
        $rows = User::orderBy('role')->orderBy('name')->get();
        // jumlah laporan per pengguna (tanpa mengubah model User bawaan Laravel)
        $jumlah = Laporan::selectRaw('id_user, COUNT(*) AS total')
            ->whereNotNull('id_user')->groupBy('id_user')->pluck('total', 'id_user');
        return view('users.index', compact('rows', 'jumlah'));
    }

    public function create()
    {
        return view('users.form', ['row' => new User(), 'roleDefault' => 'user']);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'email', 'max:150', 'unique:users,email'],
            'password' => ['required', 'min:8', 'confirmed'],
            'role' => ['required', Rule::in(['admin', 'user'])],
        ], $this->pesan(), $this->attrs());

        $user = (new User())->forceFill([
            'name' => $data['name'], 'email' => $data['email'],
            'password' => Hash::make($data['password']), 'role' => $data['role'],
        ]);
        $user->save();

        return redirect()->route('users.index')->with('ok', 'Pengguna berhasil ditambahkan.');
    }

    public function edit(User $user)
    {
        return view('users.form', ['row' => $user, 'roleDefault' => $user->role]);
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'email', 'max:150', Rule::unique('users', 'email')->ignore($user->id)],
            'password' => ['nullable', 'min:8', 'confirmed'], // kosong = tidak diganti
            'role' => ['required', Rule::in(['admin', 'user'])],
        ], $this->pesan(), $this->attrs());

        if ($user->id === Auth::id() && $data['role'] !== 'admin') {
            return back()->withInput()->withErrors(['role' => 'Anda tidak bisa menurunkan peran akun sendiri.']);
        }

        $user->forceFill([
            'name' => $data['name'], 'email' => $data['email'], 'role' => $data['role'],
        ]);
        if (!empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }
        $user->save();

        return redirect()->route('users.index')->with('ok', 'Pengguna berhasil diperbarui.');
    }

    public function destroy(User $user)
    {
        if ($user->id === Auth::id()) {
            return redirect()->route('users.index')->with('err', 'Akun yang sedang dipakai tidak bisa dihapus.');
        }
        $user->delete(); // laporan miliknya tetap ada (id_user -> NULL)
        return redirect()->route('users.index')->with('ok', 'Pengguna berhasil dihapus.');
    }
}
