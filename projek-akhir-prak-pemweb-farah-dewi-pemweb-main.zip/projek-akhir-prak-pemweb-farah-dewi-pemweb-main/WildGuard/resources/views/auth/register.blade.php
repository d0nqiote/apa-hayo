@extends('layouts.auth')
@section('title', 'Daftar')

@section('content')
<h1>Daftar Akun Pelapor</h1>
<p class="auth-sub">Dengan akun, Anda bisa melihat, mengubah, dan menghapus laporan yang pernah Anda kirim.</p>

<form method="post" action="{{ route('register') }}" class="auth-form">
  @csrf
  <div class="field">
    <label for="name">Nama</label>
    <input id="name" name="name" value="{{ old('name') }}" autocomplete="name" required autofocus>
    @error('name') <p class="error">{{ $message }}</p> @enderror
  </div>
  <div class="field">
    <label for="email">Email</label>
    <input id="email" type="email" name="email" value="{{ old('email') }}" autocomplete="username" required>
    @error('email') <p class="error">{{ $message }}</p> @enderror
  </div>
  <div class="field">
    <label for="password">Password <span class="muted small">(minimal 8 karakter)</span></label>
    <input id="password" type="password" name="password" autocomplete="new-password" required>
    @error('password') <p class="error">{{ $message }}</p> @enderror
  </div>
  <div class="field">
    <label for="password_confirmation">Ulangi password</label>
    <input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password" required>
  </div>
  <button type="submit" class="btn-primary btn-block">Daftar</button>
</form>

<p class="auth-alt">Sudah punya akun? <a href="{{ route('login') }}">Masuk</a></p>
@endsection
