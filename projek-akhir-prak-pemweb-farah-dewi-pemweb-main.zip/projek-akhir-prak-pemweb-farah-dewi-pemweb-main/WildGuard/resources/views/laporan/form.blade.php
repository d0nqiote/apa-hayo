@extends('layouts.app')
@section('title', $row->exists ? 'Ubah Laporan' : 'Buat Laporan')

@section('content')
<div class="head"><h1>{{ $row->exists ? 'Ubah' : 'Buat' }} Laporan</h1></div>

<form class="card form" method="post"
      action="{{ $row->exists ? route('laporan.update', $row) : route('laporan.store') }}">
  @csrf
  <input type="hidden" name="kembali" value="{{ old('kembali', $kembali ?? '') }}">
  @if ($row->exists) @method('PUT') @endif

  <div class="g2">
    <div class="field">
      <label>Jenis Temuan</label>
      <select name="id_jenis">
        <option value="">-- pilih --</option>
        @foreach ($jenis as $j)
          <option value="{{ $j->id_jenis }}" @selected((int) old('id_jenis', $row->id_jenis) === (int) $j->id_jenis)>
            {{ $j->nama_jenis }}
          </option>
        @endforeach
      </select>
      @error('id_jenis') <p class="error">{{ $message }}</p> @enderror
    </div>
    <div class="field">
      <label>Spesies terkait <span class="muted small">(opsional)</span></label>
      <select name="id_spesies">
        <option value="">-- tidak diketahui --</option>
        @foreach ($spesies as $s)
          <option value="{{ $s->id_spesies }}" @selected((int) old('id_spesies', $row->id_spesies) === (int) $s->id_spesies)>
            {{ $s->nama }}
          </option>
        @endforeach
      </select>
      @error('id_spesies') <p class="error">{{ $message }}</p> @enderror
    </div>
    <div class="field">
      <label>Lokasi Kejadian</label>
      <input name="lokasi_kejadian" value="{{ old('lokasi_kejadian', $row->lokasi_kejadian) }}">
      @error('lokasi_kejadian') <p class="error">{{ $message }}</p> @enderror
    </div>
    <div class="field">
      <label>Tanggal Kejadian</label>
      <input type="date" name="tanggal_kejadian" max="{{ now()->format('Y-m-d') }}"
             value="{{ old('tanggal_kejadian', $row->tanggal_kejadian?->format('Y-m-d')) }}">
      @error('tanggal_kejadian') <p class="error">{{ $message }}</p> @enderror
    </div>
  </div>
  <div class="field">
    <label>Deskripsi</label>
    <textarea name="deskripsi" rows="5" placeholder="Jelaskan apa yang Anda lihat...">{{ old('deskripsi', $row->deskripsi) }}</textarea>
    @error('deskripsi') <p class="error">{{ $message }}</p> @enderror
  </div>
  <div class="field">
    <label>Status Laporan</label>
    <select name="status_laporan">
      @foreach (['baru', 'diproses', 'selesai'] as $s)
        <option value="{{ $s }}" @selected(old('status_laporan', $row->status_laporan ?? 'baru') === $s)>{{ ucfirst($s) }}</option>
      @endforeach
    </select>
    @error('status_laporan') <p class="error">{{ $message }}</p> @enderror
  </div>
  <div class="actions">
    <button class="btn">Simpan</button>
    <a class="btn ghost" href="{{ \App\Support\Kembali::url(old('kembali', $kembali ?? ''), route('laporan.index')) }}">Batal</a>
  </div>
</form>
@endsection
