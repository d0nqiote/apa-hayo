<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>@yield('title', 'WildGuard') - WildGuard</title>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="{{ asset('css/wildguard.css') }}">
  <link rel="stylesheet" href="{{ asset('css/crud.css') }}">
</head>
<body class="halaman-dalam">
  <span id="konten"></span>
  @include('partials.navbar')

  @if (auth()->user()?->role === 'admin' && request()->is('admin*'))
    <nav class="subnav" aria-label="Menu kelola">
      <a href="{{ route('admin.dashboard') }}" class="{{ request()->routeIs('admin.dashboard') ? 'on' : '' }}">🏠 Dashboard</a>
      <a href="{{ route('spesies.index') }}" class="{{ request()->routeIs('spesies.*') ? 'on' : '' }}">🐾 Spesies</a>
      <a href="{{ route('artikel.index') }}" class="{{ request()->routeIs('artikel.*') ? 'on' : '' }}">📖 Artikel</a>
      <a href="{{ route('laporan.index') }}" class="{{ request()->routeIs('laporan.*') ? 'on' : '' }}">📮 Laporan</a>
      <a href="{{ route('users.index') }}" class="{{ request()->routeIs('users.*') ? 'on' : '' }}">👥 Pengguna</a>
      <details class="dd {{ request()->routeIs('master.*') ? 'on' : '' }}">
        <summary>🗂️ Data Master ▾</summary>
        <div>
          <a href="{{ route('master.index', 'status') }}">Status Perlindungan</a>
          <a href="{{ route('master.index', 'lokasi') }}">Lokasi</a>
          <a href="{{ route('master.index', 'kategori') }}">Kategori Artikel</a>
          <a href="{{ route('master.index', 'jenis') }}">Jenis Temuan</a>
        </div>
      </details>
    </nav>
  @endif

  <main class="crud">
    @if (session('ok')) <div class="alert ok">{{ session('ok') }}</div> @endif
    @if (session('err')) <div class="alert err">{{ session('err') }}</div> @endif
    @yield('content')
  </main>

  @include('partials.footer')
  <script src="{{ asset('js/nav.js') }}"></script>
</body>
</html>
