# 🌿 WildGuard

> Platform web edukasi untuk mengenal flora dan fauna yang dilindungi serta meningkatkan kesadaran masyarakat terhadap perdagangan ilegal satwa liar, sebagai bentuk dukungan terhadap **SDG 15.7**.

Proyek akhir praktikum **Pemrograman Web**, dibangun dengan Laravel dan MySQL.

---

## 👥 Anggota Kelompok

| No | Nama | NIM |
|----|------|-----|
| 1 | Kaila Audriya Setiawan | 140810250007 |
| 2 | Farah Nadia Aqila | 140810250049 |
| 3 | Naura Alifia Lubna | 140810250088 |

---

## 🎯 Tujuan

WildGuard dibuat untuk mendukung **Sustainable Development Goals (SDGs) Tujuan 15: Life on Land**, khususnya **target 15.7**:

> Mengambil tindakan untuk mengakhiri perburuan dan perdagangan ilegal spesies flora dan fauna yang dilindungi.

Platform ini membantu masyarakat untuk:

- Mengenal flora dan fauna yang dilindungi.
- Mengetahui status perlindungan suatu spesies (Nasional, IUCN, CITES).
- Memahami ancaman terhadap flora dan fauna.
- Meningkatkan kesadaran tentang perdagangan ilegal satwa liar.
- Mencatat dugaan temuan perdagangan ilegal flora dan fauna.

**Target pengguna:** pelajar dan mahasiswa, masyarakat umum, pecinta lingkungan dan satwa, serta siapa pun yang ingin mempelajari flora dan fauna Indonesia.

---

## ✨ Fitur

**Untuk semua pengunjung (tanpa login)**
- Melihat katalog flora dan fauna dilindungi (kartu dan detail) beserta status, lokasi sebaran, habitat, dan fakta menarik.
- Membaca artikel edukasi yang sudah terbit.
- Mengerjakan kuis pengetahuan (soal dari admin, atau soal acak dari data spesies bila belum ada).
- Melihat peta sebaran laporan (Leaflet). Koordinat dibulatkan demi keamanan pelapor, dan hanya laporan yang sudah diproses yang tampil.
- Mengirim laporan temuan secara anonim, dengan lokasi, tanggal, deskripsi, koordinat (opsional), dan lampiran foto/PDF (opsional).

**Untuk user terdaftar**
- Register dan login.
- **Laporan Saya:** melihat, mengubah, dan menghapus laporan sendiri selama statusnya masih `baru`.
- **Artikel Saya:** mengusulkan artikel (status `menunggu`), lalu mengubah atau menghapusnya selama belum disetujui admin.

**Untuk admin** (panel `/admin`)
- Dashboard ringkasan data.
- CRUD spesies (termasuk relasi lokasi sebaran M:N).
- CRUD artikel dan menyetujui usulan artikel dari user.
- Melihat laporan, mengubah status (`baru` → `diproses` → `selesai`), dan menghapus laporan.
- Mengelola soal kuis (tambah, ubah, hapus, aktif/nonaktifkan).
- CRUD data master: status perlindungan, lokasi, kategori artikel, dan jenis temuan.
- Mengelola pengguna.

### Hak akses

| Peran | Baca situs | Kirim laporan | Laporan Saya | Artikel Saya | Panel `/admin` |
|---|:-:|:-:|:-:|:-:|:-:|
| Pengunjung | ✔ | ✔ (anonim) | ✘ | ✘ | ✘ |
| User | ✔ | ✔ (tercatat atas akunnya) | ✔ | ✔ | ✘ |
| Admin | ✔ | ✔ | ✔ | ✔ | ✔ |

---

## 🛠️ Teknologi

| Bagian | Teknologi |
|---|---|
| Backend | PHP ^8.3, Laravel ^13.17 |
| Database | MySQL / MariaDB |
| Autentikasi | Session Laravel (`laravel/sanctum` terpasang, belum dipakai untuk API) |
| Frontend | Blade, CSS dan JavaScript biasa (`public/css`, `public/js`) |
| Peta | Leaflet 1.9.4 (lewat CDN, butuh koneksi internet) |
| Font | Quicksand (Google Fonts) |

---

## 📁 Struktur Folder

```
.
├── index.html, script.js, style.css   # prototipe statis awal (tugas Pemrograman Web)
├── schema.sql                         # skema awal database (versi praktikum Sistem Database)
├── WildGuard/                         # aplikasi Laravel (yang dipakai untuk demo)
│   ├── app/Http/Controllers/          # Home, Auth, Spesies, Artikel, Laporan, KuisSoal, Master, dll.
│   ├── app/Http/Middleware/AdminOnly.php
│   ├── app/Models/
│   ├── database/migrations/           # struktur tabel
│   ├── database/seeders/              # data awal + akun demo
│   ├── resources/views/               # tampilan Blade
│   ├── public/css, public/js          # aset front-end
│   └── routes/web.php                 # seluruh rute aplikasi
└── README.md
```

---

## 🚀 Cara Menjalankan

### Prasyarat
- PHP 8.3 atau lebih baru (ekstensi umum Laravel, termasuk `pdo_mysql`)
- Composer
- MySQL atau MariaDB (misalnya lewat XAMPP/Laragon)

### Langkah

1. **Masuk ke folder aplikasi**
   ```bash
   cd WildGuard
   ```

2. **Pasang dependensi**
   ```bash
   composer install
   ```

3. **Siapkan file environment**
   ```bash
   cp .env.example .env
   php artisan key:generate
   ```

4. **Buat database** bernama `wildguard` di MySQL, lalu atur koneksi di `.env`:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=wildguard
   DB_USERNAME=root
   DB_PASSWORD=
   ```

5. **Buat tabel dan isi data awal**
   ```bash
   php artisan migrate --seed
   ```

6. **Jalankan server**
   ```bash
   php artisan serve
   ```
   Buka <http://127.0.0.1:8000>.

> Aplikasi ini memakai CSS dan JS langsung dari folder `public/`, jadi `npm install` dan `npm run build` tidak diperlukan untuk menjalankannya.

### Akun demo

| Peran | Email | Password |
|---|---|---|
| Admin | `admin@wildguard.test` | `admin12345` |
| User | `user@wildguard.test` | `user12345` |

> ⚠️ Ganti password akun demo setelah presentasi.

---

## 🗄️ Database

Tabel utama:

| Tabel | Fungsi |
|---|---|
| `users` | akun pengguna, kolom `role` (`admin` / `user`) |
| `status_perlindungan` | status perlindungan (Nasional / IUCN / CITES) |
| `lokasi` | lokasi sebaran |
| `spesies` | data flora dan fauna |
| `spesies_lokasi` | relasi M:N spesies dan lokasi |
| `kategori_artikel` | kategori artikel |
| `artikel` | artikel edukasi (status `menunggu` / `terbit`, penulis opsional) |
| `jenis_temuan` | jenis temuan untuk laporan |
| `laporan` | laporan temuan (status `baru` / `diproses` / `selesai`, koordinat, lampiran) |
| `kuis_soal` | soal kuis buatan admin |

### ERD

```mermaid
erDiagram
    STATUS_PERLINDUNGAN ||--o{ SPESIES : "menetapkan status"
    SPESIES ||--o{ SPESIES_LOKASI : "tersebar di"
    LOKASI ||--o{ SPESIES_LOKASI : "dihuni"
    KATEGORI_ARTIKEL ||--o{ ARTIKEL : "mengelompokkan"
    JENIS_TEMUAN ||--o{ LAPORAN : "diklasifikasikan"
    SPESIES |o--o{ LAPORAN : "disebut dalam"
    USERS |o--o{ LAPORAN : "mengirim (opsional)"
    USERS |o--o{ ARTIKEL : "menulis / mengusulkan"
```

Aturan hapus (`ON DELETE`):
- `RESTRICT` pada status, kategori, dan jenis temuan: tidak bisa dihapus selama masih dipakai.
- `CASCADE` pada `spesies_lokasi`: hapus spesies atau lokasi ikut menghapus baris penghubungnya.
- `SET NULL` pada `laporan.id_spesies`, `laporan.id_user`, dan `artikel.id_user`: data tetap ada walau spesies atau akunnya dihapus.

Skema tabel selengkapnya (tipe data dan kunci) ada di folder `WildGuard/database/migrations`.

---

## 🔗 Ringkasan Rute

| Area | Rute |
|---|---|
| Publik | `/`, `/landing`, `POST /lapor`, `/peta/laporan` (JSON) |
| Auth | `/masuk`, `/daftar`, `POST /keluar` |
| User | `/laporan-saya`, `/artikel-saya` |
| Admin | `/admin`, `/admin/spesies`, `/admin/artikel`, `/admin/laporan`, `/admin/kuis-soal`, `/admin/master/{status\|lokasi\|kategori\|jenis}` |

Total ada 52 endpoint. Daftar lengkap beserta contoh request dan response ada di berkas **Dokumentasi API WildGuard**.

---

## 🔒 Catatan Keamanan

- Jangan commit file `.env`. Pastikan masuk `.gitignore` dan ganti `APP_DEBUG=false` untuk produksi.
- Lampiran laporan disimpan di `public/uploads/laporan` sehingga bisa diakses lewat URL langsung. Untuk produksi, pertimbangkan penyimpanan privat.
- Login dan registrasi dibatasi 10 percobaan per menit.

---

## 💡 Ide Pengembangan

- Verifikasi email dan reset password.
- Statistik sebaran laporan per wilayah.
- Notifikasi ke BKSDA saat laporan baru masuk.
- API untuk aplikasi mobile.

---

## 📜 Lisensi

Proyek ini dibuat untuk keperluan pembelajaran (praktikum Pemrograman Web).